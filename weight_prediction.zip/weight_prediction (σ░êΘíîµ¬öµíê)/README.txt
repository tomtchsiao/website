Guide of this project:

Using Mac/Linux terminal, please make sure that install PYTHON and PIP.
Install flask package via input (1).
Next, type below command to view the result.
> pip install flask (1)
> export FLASK_APP=app.py
> export FLASK_ENV=development
> flask run

Others, using Command line to verify PYTHON (Must add in ENV) and PIP is installed or not.
Then, using (1) to install flask package.
Last, input (2) to view the result.
> pip install flask (1)
> python app.py (2)